module.exports = {
        translation: {
          SKILL_NAME: 'Virtusa <say-as interpret-as="spell-out">EAG</say-as> <say-as interpret-as="spell-out">BI</say-as>',
          GET_REVENUE_MESSAGE: "Your revenue forecast is ",
          GET_MARGIN_MESSAGE: "Your acount margin is ",
          GET_ATTRITION_MESSAGE: "Your attrition is ",
          WELCOME_MESSAGE: "Bem vindo a Nutriclinic"+
          "Um espasso para o seu desenvolvimento e relaxamento"+
          "Meu nome eh Alexa, e espero poder te ajudar<break/>",
          WELCOME_MESSAGE2:  
          "Para conhecer nosso serviços diga CONHECER SERVIÇOS<break/> "+
          "Para agendamentos diga FAZER AGENDAMENTO<break/> "+
          "Para deixar uma mensagem ou recado DEIXAR MENSAGEM<break/>"+
          "Para horário de atendimento diga HORÁRIO DE ATENDIMENTO<break/>",
          WELCOME_PROMPT: '.  Qual opção gostaria?<break/>',
          OTHER_MESSAGE_REVENUE: '.  You can also say whats my margin, whats my attrition, or, you can say exit',
          OTHER_MESSAGE_MARGIN: '.  You can also say whats my revenue, whats my attrition, or, you can say exit',
          OTHER_MESSAGE_ATTRITION: '.  You can also say whats my revenue, whats my margin, or, you can say exit',
          DONTUNDERSTAND_MESSAGE: 'Sorry, I dont understand. ',
          HELP_MESSAGE: 'You can say whats my revenue, whats my margin, whats my attrition, or, you can say exit... What can I help you with?',
          HELP_REPROMPT: 'What can I help you with?',
          STOP_MESSAGE: 'Goodbye, have a nice day!',
          ACCOUNT_LINK_MESSAGE: 'Please link your Virtusa account to use this skill.',
        },
      }
